QH Mare Master 01 — ARTIST STARTER PACK

The approved master is immutable and included byte-for-byte as qh_mare_master_01_immutable_reference.png. Canvas: 1496 × 1051px. The blank registered canvas is a fully transparent RGBA PNG. Never crop, resize, rotate, or reposition. NONE means apply no layer and is not an asset requirement. LF/RF/LH/RH refer to the horse's anatomical limbs, never screen position. Export PNG or WebP at exact canvas size. Uploads begin in Review and require explicit Owner approval and separate Production promotion.
