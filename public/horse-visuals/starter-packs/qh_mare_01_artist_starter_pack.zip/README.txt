QH Mare Master 01 — ARTIST STARTER PACK

The approved master is immutable. Canvas: 1496 × 1051px. Never crop, resize, rotate, or reposition. Create artwork only on the transparent registered canvas. Preserve alpha outside the intended layer. LF/RF/LH/RH refer to the horse's anatomical limbs, never screen position. Export PNG or WebP at exact canvas size. Production layer order is documented in layer-order.txt. Uploads begin in Review and require explicit Owner approval and separate Production promotion.
